#!/usr/bin/env node
/**
 * 生成项目自带的样本 trace(samples/trace.zip):用本机 Chrome for Testing 访问一个
 * 内置的两页 SaaS demo(登录 -> 仪表盘),录下约 10 个交互 action。
 *
 * 用途:
 *   - 作为截图脚本(scripts/screenshots.mjs)稳定、自主可控的 trace 来源,
 *     不依赖任何外部项目的 test-results(会被清理);
 *   - 同时补齐 verify-viewer.mjs 默认查找的 samples/trace.zip。
 *
 * playwright-core 1.63 录制 -> trace schema v9。
 * 用法: node scripts/generate-sample-trace.mjs
 */
import { createServer } from 'node:http';
import { existsSync, mkdirSync, readdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { chromium } from 'playwright-core';

const ROOT = process.cwd();
const OUT_DIR = join(ROOT, 'samples');

function resolveBrowser() {
  if (process.env.CFT_EXE) return process.env.CFT_EXE;
  const cache = join(homedir(), 'Library', 'Caches', 'ms-playwright');
  for (const d of readdirSync(cache).filter((n) => n.startsWith('chromium-')).sort().reverse()) {
    for (const sub of ['chrome-mac-arm64', 'chrome-mac']) {
      const cft = join(cache, d, sub, 'Google Chrome for Testing.app', 'Contents', 'MacOS', 'Google Chrome for Testing');
      if (existsSync(cft)) return cft;
    }
  }
  throw new Error('未找到可用的 Chrome for Testing');
}

// ───────── demo 页面:现代 SaaS 登录页 ─────────
const LOGIN = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>登录 · Acme Cloud</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"Segoe UI","PingFang SC",sans-serif;height:100vh;display:flex}
.left{flex:1.1;background:linear-gradient(135deg,#6366f1,#8b5cf6 55%,#d946ef);display:flex;flex-direction:column;justify-content:center;padding:0 7vw;color:#fff}
.left h1{font-size:38px;line-height:1.25;margin-bottom:16px}
.left p{font-size:15px;opacity:.85;max-width:380px;line-height:1.7}
.left .dots{display:flex;gap:8px;margin-top:34px}
.left .dots i{width:9px;height:9px;border-radius:50%;background:rgba(255,255,255,.5)}
.left .dots i.on{background:#fff;width:26px;border-radius:5px}
.right{flex:1;display:flex;align-items:center;justify-content:center;background:#fafafe}
.card{width:380px;background:#fff;border:1px solid #eee;border-radius:14px;padding:38px 34px;box-shadow:0 20px 50px rgba(80,70,180,.10)}
.logo{display:flex;align-items:center;gap:10px;margin-bottom:26px}
.logo b{width:34px;height:34px;border-radius:9px;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px}
.logo span{font-weight:700;font-size:17px}
label{display:block;font-size:12.5px;font-weight:600;color:#444;margin:16px 0 7px}
input{width:100%;padding:11px 13px;border:1px solid #d9dbe4;border-radius:8px;font-size:14px;outline:none}
input:focus{border-color:#7c7ff0;box-shadow:0 0 0 3px rgba(99,102,241,.13)}
.row{display:flex;justify-content:space-between;align-items:center;margin:16px 0 22px;font-size:12.5px;color:#666}
.row a{color:#6366f1;text-decoration:none}
button{width:100%;padding:12px;border:none;border-radius:8px;background:linear-gradient(135deg,#6366f1,#7c5cf5);color:#fff;font-size:15px;font-weight:600;cursor:pointer}
.foot{text-align:center;margin-top:20px;font-size:12.5px;color:#888}
.foot a{color:#6366f1;text-decoration:none}
</style></head><body>
  <div class="left">
    <h1>团队协作的<br>一体化云平台</h1>
    <p>把项目、数据与自动化流程集中管理,实时洞察团队效能,让每一次交付都更快、更稳。</p>
    <div class="dots"><i class="on"></i><i></i><i></i></div>
  </div>
  <div class="right">
    <form class="card" action="/dashboard" method="get">
      <div class="logo"><b>A</b><span>Acme Cloud</span></div>
      <label for="email">邮箱地址</label>
      <input id="email" name="email" type="email" placeholder="you@company.com" value="">
      <label for="password">密码</label>
      <input id="password" name="password" type="password" placeholder="请输入密码">
      <div class="row"><span>☑ 记住我</span><a href="#">忘记密码?</a></div>
      <button type="submit">登 录</button>
      <p class="foot">还没有账号? <a href="#">免费注册</a></p>
    </form>
  </div>
</body></html>`;

// ───────── demo 页面:仪表盘 ─────────
const DASHBOARD = `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">
<title>仪表盘 · Acme Cloud</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"Segoe UI","PingFang SC",sans-serif;background:#f5f6fa;color:#2b2d42;display:flex;min-height:100vh}
aside{width:232px;background:#1e1f3a;color:#c3c5e0;display:flex;flex-direction:column;flex:none}
aside .brand{display:flex;align-items:center;gap:10px;padding:20px 22px;color:#fff;font-weight:700}
aside .brand i{width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,#6366f1,#8b5cf6);display:flex;align-items:center;justify-content:center;font-style:normal}
.nav a{display:flex;align-items:center;gap:11px;padding:11px 22px;font-size:13.5px;color:#aab;border-left:3px solid transparent;cursor:pointer;text-decoration:none}
.nav a .ic{width:16px;text-align:center}
.nav a.active{background:#2a2c52;color:#fff;border-left-color:#8b5cf6}
.nav a:hover{color:#fff}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.top{height:62px;background:#fff;border-bottom:1px solid #eceef3;display:flex;align-items:center;gap:16px;padding:0 26px}
.top h2{font-size:16px;font-weight:600}
.search{margin-left:auto;position:relative}
.search input{width:230px;padding:8px 12px 8px 32px;border:1px solid #e0e2ea;border-radius:8px;font-size:13px;outline:none}
.avatar{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700}
.content{padding:24px 26px}
.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:22px}
.kpi{background:#fff;border-radius:12px;padding:18px;box-shadow:0 2px 8px rgba(30,31,58,.05)}
.kpi .t{font-size:12px;color:#8a8da3;margin-bottom:8px}
.kpi .n{font-size:24px;font-weight:700}
.kpi .d{font-size:11.5px;margin-top:6px}
.up{color:#16a34a}.down{color:#dc2626}
.panel{background:#fff;border-radius:12px;padding:20px;box-shadow:0 2px 8px rgba(30,31,58,.05);margin-bottom:20px}
.panel h3{font-size:14px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center}
.panel h3 span{font-size:11.5px;color:#9aa;font-weight:400}
.grid2{display:grid;grid-template-columns:1.4fr 1fr;gap:16px}
.bars{display:flex;align-items:flex-end;gap:14px;height:170px;padding-top:10px}
.bar{flex:1;background:linear-gradient(180deg,#8b5cf6,#6366f1);border-radius:6px 6px 0 0;position:relative}
.bar small{position:absolute;top:-18px;left:50%;transform:translateX(-50%);font-size:10px;color:#777}
.bar i{position:absolute;bottom:-20px;left:50%;transform:translateX(-50%);font-style:normal;font-size:10px;color:#999}
.donut-wrap{display:flex;align-items:center;gap:18px}
.legend{font-size:12.5px;line-height:2}
.legend i{display:inline-block;width:9px;height:9px;border-radius:2px;margin-right:7px}
table{width:100%;border-collapse:collapse;font-size:13px}
th{text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#9aa;padding:0 10px 10px;border-bottom:1px solid #eef0f5}
td{padding:11px 10px;border-bottom:1px solid #f3f4f8}
.tag{padding:2px 9px;border-radius:10px;font-size:11px;font-weight:600}
.t-ok{background:#e7f7ee;color:#16a34a}.t-run{background:#fef3e2;color:#d97706}.t-fail{background:#fdeaea;color:#dc2626}
.section{display:none}.section.on{display:block}
</style></head><body>
  <aside>
    <div class="brand"><i>A</i> Acme Cloud</div>
    <nav class="nav">
      <a class="active" data-sec="overview"><span class="ic">▦</span> 概览</a>
      <a data-sec="analytics"><span class="ic">📈</span> 数据分析</a>
      <a data-sec="runs"><span class="ic">▶</span> 测试运行</a>
      <a data-sec="settings"><span class="ic">⚙</span> 设置</a>
    </nav>
  </aside>
  <div class="main">
    <div class="top">
      <h2 id="page-title">概览</h2>
      <div class="search"><input id="search" placeholder="搜索用例、报告…"></div>
      <div class="avatar">YF</div>
    </div>
    <div class="content">
      <div class="section on" id="overview">
        <div class="cards">
          <div class="kpi"><div class="t">总用例数</div><div class="n">1,284</div><div class="d up">▲ 12.4% 较上周</div></div>
          <div class="kpi"><div class="t">通过率</div><div class="n">94.2%</div><div class="d up">▲ 2.1%</div></div>
          <div class="kpi"><div class="t">本月运行</div><div class="n">368</div><div class="d up">▲ 8.0%</div></div>
          <div class="kpi"><div class="t">平均耗时</div><div class="n">4m 12s</div><div class="d down">▼ 快了 36s</div></div>
        </div>
        <div class="grid2">
          <div class="panel">
            <h3>每周执行趋势 <span>最近 7 周</span></h3>
            <div class="bars">
              <div class="bar" style="height:48%"><small>210</small><i>W1</i></div>
              <div class="bar" style="height:62%"><small>268</small><i>W2</i></div>
              <div class="bar" style="height:55%"><small>241</small><i>W3</i></div>
              <div class="bar" style="height:74%"><small>312</small><i>W4</i></div>
              <div class="bar" style="height:66%"><small>287</small><i>W5</i></div>
              <div class="bar" style="height:84%"><small>356</small><i>W6</i></div>
              <div class="bar" style="height:92%"><small>368</small><i>W7</i></div>
            </div>
          </div>
          <div class="panel">
            <h3>用例分布</h3>
            <div class="donut-wrap">
              <svg width="130" height="130" viewBox="0 0 42 42">
                <circle cx="21" cy="21" r="15.9" fill="none" stroke="#6366f1" stroke-width="6" stroke-dasharray="62 38" stroke-dashoffset="25"/>
                <circle cx="21" cy="21" r="15.9" fill="none" stroke="#a78bfa" stroke-width="6" stroke-dasharray="24 76" stroke-dashoffset="-37"/>
                <circle cx="21" cy="21" r="15.9" fill="none" stroke="#e9d5ff" stroke-width="6" stroke-dasharray="14 86" stroke-dashoffset="-61"/>
              </svg>
              <div class="legend">
                <div><i style="background:#6366f1"></i>UI 自动化 62%</div>
                <div><i style="background:#a78bfa"></i>接口测试 24%</div>
                <div><i style="background:#e9d5ff"></i>单元测试 14%</div>
              </div>
            </div>
          </div>
        </div>
        <div class="panel">
          <h3>最近的测试运行 <span>实时</span></h3>
          <table>
            <tr><th>运行</th><th>套件</th><th>用例</th><th>耗时</th><th>状态</th></tr>
            <tr><td>#368</td><td>login-regression</td><td>42</td><td>4m 12s</td><td><span class="tag t-ok">通过</span></td></tr>
            <tr><td>#367</td><td>checkout-flow</td><td>18</td><td>6m 48s</td><td><span class="tag t-run">运行中</span></td></tr>
            <tr><td>#366</td><td>dashboard-ui</td><td>27</td><td>3m 05s</td><td><span class="tag t-fail">失败 2</span></td></tr>
            <tr><td>#365</td><td>search-api</td><td>56</td><td>1m 52s</td><td><span class="tag t-ok">通过</span></td></tr>
          </table>
        </div>
      </div>
      <div class="section" id="analytics"><p style="color:#888">数据分析视图</p></div>
      <div class="section" id="runs"><p style="color:#888">测试运行视图</p></div>
      <div class="section" id="settings"><p style="color:#888">设置视图</p></div>
    </div>
  </div>
<script>
const titles={overview:'概览',analytics:'数据分析',runs:'测试运行',settings:'设置'};
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>{
  document.querySelectorAll('.nav a').forEach(x=>x.classList.remove('active'));
  a.classList.add('active');
  document.querySelectorAll('.section').forEach(s=>s.classList.remove('on'));
  document.getElementById(a.dataset.sec).classList.add('on');
  document.getElementById('page-title').textContent=titles[a.dataset.sec];
  if(a.dataset.sec==='analytics')fetch('/api/analytics').catch(()=>{});
}));
</script>
</body></html>`;

const server = createServer((req, res) => {
  const p = new URL(req.url, 'http://x');
  if (p.pathname === '/' || p.pathname === '/login') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(LOGIN);
  } else if (p.pathname === '/dashboard') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(DASHBOARD);
  } else if (p.pathname === '/api/analytics') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ ok: true, points: [12, 18, 25, 31] }));
  } else {
    res.writeHead(404).end();
  }
});

let browser;
try {
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  const { port } = server.address();
  const base = `http://127.0.0.1:${port}`;

  browser = await chromium.launch({ executablePath: resolveBrowser(), headless: true });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  await context.tracing.start({ screenshots: true, snapshots: true, sources: true });

  // 录制约 10 个交互 action
  await page.goto(`${base}/login`);
  await page.fill('#email', 'yufeng@acme.com');
  await page.fill('#password', 'playwright-2026');
  await page.click('button[type=submit]');
  await page.waitForURL(/\/dashboard/);
  await page.fill('#search', 'login-regression');
  await page.click('.nav a[data-sec="analytics"]');
  await page.click('.nav a[data-sec="overview"]');
  await page.hover('.kpi:nth-child(2)');
  await page.click('table tr:nth-child(3)');

  mkdirSync(OUT_DIR, { recursive: true });
  await context.tracing.stop({ path: join(OUT_DIR, 'trace.zip') });
  console.log('已生成 samples/trace.zip');
} catch (e) {
  console.error('失败:', e);
  process.exitCode = 1;
} finally {
  if (browser) await browser.close().catch(() => {});
  await new Promise((r) => server.close(r));
}
